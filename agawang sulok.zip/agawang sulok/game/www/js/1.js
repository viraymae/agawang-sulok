var w=800,h= 500;

var player,keyboard;
        var platforms, 
        
        scoreText,gameOverText,livesText,
       
        gameOverText,
        hulitext,
        timeText,
        bestText;
        var pause,restart;
        var score=0;
        var harry,liam,louis,niall,tween;
       
        var lives= 0;
var game= new Phaser.Game(w, h, Phaser.CANVAS, 'display_game');
var basicGame = function(){
}
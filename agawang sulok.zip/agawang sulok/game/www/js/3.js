var process = function() {
	   "use strict";
        return {

      
kill:function(player,harry,liam,louis,niall){
if(player.kill()){
    hulitext.text= "huli ka!";

}
},

     timer: function(initTime,microsec){
        setInterval(function(){
            initTime--;
            if(initTime>=0){        
                timeText.text = "Time: "+initTime;
            }
            else{
                game._paused = true;

             gameOverText.text="MAGALING!! \n Best:"+process.getData() +"\n Score:"+score, +"\n Eggs:"+ lives,{
            fontSize:'30px', fill:'white', stroke:'black', strokeThickness: '40' }  
                }
            },microsec);
    },


     saveData:function(score){
        localStorage.setItem("gameData",score);
    },


     getData:function(){
        var data= localStorage.getItem("gameData");
        if(data==null|| data==""){
            data=0
        }
        return data;
    },


     pause:function(){
        this.game.paused = true;

        var stopText = this.add.image(w/2, 250, 'picpause');

        this.input.onDown.add (function(){ 
            stopText.destroy();
            this.game.paused = false;
            }, this);        
    },

    restart:function(){
        location.reload();
    },




}

}();

basicGame.prototype = {
	preload: function(){
		game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
        game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;

        game.stage.backgroundColor = 'lightblue';
		
		game.load.image("base1","img/base1.png", 100,100);
        game.load.image("base2","img/base2.png", 200,200);
        game.load.image("base3","img/base3.png", 300,300);
        game.load.image("base4","img/base4.png", 400,400);
        game.load.spritesheet ("harry","img/harry.png", 72,117);
        game.load.spritesheet ("liam","img/liam.png", 72,117);
        game.load.spritesheet ("louis","img/louis.png", 72,117);
        game.load.spritesheet ("niall","img/niall.png", 72,117);
        game.load.image("pause","img/pause1.png",50,50);
        game.load.image("restart","img/play again.png",50,50);
        game.load.spritesheet('taya', 'img/zayn.png', 72,117);
        game.load.image('bg', 'img/damo.jpg');
        game.load.image('picpause', 'img/playbutton.png' , 400, 200);
        

                 
	},
	create: function(){
		game.physics.startSystem(Phaser.Physics.ARCADE);
        game.world.setBounds(-20, -20, game.width + 20, game.height + 20);
        land = game.add.tileSprite(1, 1, 800, 600, 'bg');
        land.fixedToCamera = true;
		
		 game.add.image(25,300, "base1");
		 game.add.image(575,300, "base2");
		 game.add.image(575,50, "base3");
		 game.add.image(25,50, "base4");
		 
		 harry=game.add.sprite(650, 300, "harry");
		 liam=game.add.sprite(100, 100, "liam");
		 louis=game.add.sprite(650, 100, "louis");
		 niall=game.add.sprite(100, 300, "niall");
		

        player=game.add.sprite(540,240,'taya');
        player.anchor.setTo(0.5, 0.5);


        game.physics.enable(player, Phaser.Physics.ARCADE);   
        
        player.body.allowRotation = false;

    game.physics.arcade.enable(player);
    game.physics.arcade.enable(harry);
    game.physics.arcade.enable(liam);
    game.physics.arcade.enable(louis);
    game.physics.arcade.enable(niall);
   
    player.body.collideWorldBounds = true;
    harry.body.collideWorldBounds = true;
    liam.body.collideWorldBounds = true;
    louis.body.collideWorldBounds = true;
    niall.body.collideWorldBounds = true;
       
        process.timer(60,1000);


        
		base1=game.add.group();
		base1.enableBody=true
		
		base2=game.add.group();
		base2.enableBody=true
		
		base3=game.add.group();
		base3.enableBody=true
		
		base4=game.add.group();
		base4.enableBody=true
		
           
        scoreText= game.add.text(591,25,'Score: ',
            {
                fontSize:'30px', fill:'white'
            });
         bestText= game.add.text(591,50,'Best Score: '+process.getData(),
            {
                fontSize:'30px', fill:'white'
            });
        gameOverText = game.add.text((w/2)-100,200,"",{
            fontSize:'30px', fill:'white'
        });

        timeText = game.add.text(100,20,"Time: Go!!!!",{
            fontSize:'30px',fill:"white"});
         hulitext = game.add.text((w/2)-100,200,"",{
            fontSize:'30px', fill:'white'
        });


      


        pause = game.add.button(125, 450, 'pause',process.pause,this,1,0);
        pause.scale.x = .5;
        pause.scale.y = .5;


        btn = game.add.button(50,450,"restart",process.restart); 
        btn.scale.x = .5;
        btn.scale.y = .5; 


      
       
    tween=game.add.tween(harry).to({x:500},3000,Phaser.Easing.Default,true,200,1000,true);
    tween=game.add.tween(liam).to({x:50},3000,Phaser.Easing.Default,true,200,1000,true);
    tween=game.add.tween(louis).to({y:50},3000,Phaser.Easing.Default,true,200,1000,true);
    tween=game.add.tween(niall).to({y:50},3000,Phaser.Easing.Default,true,200,1000,true);
    },
	update: function(){
        // game.physics.arcade.collide(player,harry);
        // game.physics.arcade.collide(player,liam);
        // game.physics.arcade.collide(player,louis);
        // game.physics.arcade.collide(player,niall);

        game.physics.arcade.overlap(player,harry,process.kill);
        game.physics.arcade.overlap(player,liam,process.kill);
        game.physics.arcade.overlap(player,louis,process.kill);
        game.physics.arcade.overlap(player,niall,process.kill);
      
    player.rotation = game.physics.arcade.moveToPointer(player, 60, game.input.activePointer, 500);       
    

	},

}
game.state.add("gameplay",basicGame, true);
